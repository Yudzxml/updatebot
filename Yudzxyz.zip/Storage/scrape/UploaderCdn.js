const fs = require('fs');
const axios = require('axios');
const path = require('path');
const FormData = require('form-data');
const pathModule = require('path');

async function AutoresbotCdn(filePath, expired = '6months') {
  try {
    const form = new FormData();
    form.append('expired', expired);
    form.append('file', fs.createReadStream(filePath));

    const response = await axios.put(
      'https://autoresbot.com/tmp-files/upload',
      form,
      {
        headers: {
          ...form.getHeaders(),
          Referer: 'https://autoresbot.com/',
          'User-Agent':
            'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36 Edg/126.0.0.0',
        },
      }
    );
    return response.data;
  } catch (error) {
    return { error: error.message };
  }
}

async function YudzCdn(filePath) {
  const fileName = pathModule.basename(filePath);
  const form = new FormData();
  form.append('file', fs.createReadStream(filePath), fileName);

  try {
    const response = await axios.post('https://apiku.x-server.my.id/upload', form, {
      headers: form.getHeaders(),
    });

    if (response.data && response.data.success) {
      return response.data
    } else {
      throw new Error(response.data.message || 'Upload failed');
    }
  } catch (err) {
    return { error: `Upload gagal: ${err.message}` };
  }
}

async function YudzGithubCdn(filePath) {
  const fileBuffer = fs.readFileSync(filePath);
  const fileName = path.basename(filePath);

  try {
    const response = await axios.post('https://api-upload-cyan.vercel.app/api/upload', fileBuffer, {
      headers: {
        'Content-Type': 'application/octet-stream',
        'x-filename': fileName,
      },
    });

    return response.data;
  } catch (err) {
    return { error: err.response?.data || err.message };
  }
}


// --- Export semua fungsi ---
module.exports = {
  YudzCdn,
  YudzGithubCdn,
  AutoresbotCdn
};