const axios = require('axios');
const fs = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

// Pastikan direktori tmp ada
const tmpDir = path.join(__dirname, 'tmp');
if (!fs.existsSync(tmpDir)) {
    fs.mkdirSync(tmpDir);
}

const ytiz = {
    info: async (url) => {
        const data = JSON.stringify({
            "url": url,
            "startTime": 0,
            "endTime": 0,
            "format": "mp3"
        });

        const config = {
            method: 'POST',
            url: 'https://m1.fly.dev/api/info',
            headers: {
                'User-Agent': 'Mozilla/5.0 (Android 10; Mobile; rv:131.0) Gecko/131.0 Firefox/131.0',
                'Content-Type': 'application/json',
                'accept-language': 'id-ID',
                'referer': 'https://ytiz.xyz/',
                'origin': 'https://ytiz.xyz',
                'sec-fetch-dest': 'empty',
                'sec-fetch-mode': 'cors',
                'sec-fetch-site': 'cross-site',
                'priority': 'u=0',
                'te': 'trailers'
            },
            data: data
        };

        const api = await axios.request(config);
        console.log('Respons info:', api.data); // Log respons info
        return api.data;
    },
    download: async (url) => {
        const { filename, randID } = await ytiz.info(url);
        console.log('Filename:', filename, 'RandID:', randID); // Log filename dan randID

        const data = JSON.stringify({
            "url": url,
            "quality": "128",
            "metadata": true,
            "filename": filename,
            "randID": randID,
            "trim": false,
            "startTime": 0,
            "endTime": 0,
            "format": "mp3"
        });

        const config = {
            method: 'POST',
            url: 'https://m1.fly.dev/api/download',
            headers: {
                'User-Agent': 'Mozilla/5.0 (Android 10; Mobile; rv:131.0) Gecko/131.0 Firefox/131.0',
                'Content-Type': 'application/json',
                'accept-language': 'id-ID',
                'referer': 'https://ytiz.xyz/',
                'origin': 'https://ytiz.xyz',
                'sec-fetch-dest': 'empty',
                'sec-fetch-mode': 'cors',
                'sec-fetch-site': 'cross-site',
                'priority': 'u=4',
                'te': 'trailers'
            },
            data: data
        };

        const api = await axios.request(config);
        console.log('Respons download:', api.data);
        return api.data;
    },
    getBuffer: async (url) => {
        const { filepath, randID } = await ytiz.download(url);
        console.log('Filepath:', filepath, 'RandID:', randID); 

        const data = JSON.stringify({
            "filepath": filepath,
            "randID": randID
        });

        const config = {
            method: 'POST',
            url: 'https://m1.fly.dev/api/file_send',
            headers: {
                'User-Agent': 'Mozilla/5.0 (Android 10; Mobile; rv:131.0) Gecko/131.0 Firefox/131.0',
                'Content-Type': 'application/json',
                'accept-language': 'id-ID',
                'referer': 'https://ytiz.xyz/',
                'origin': 'https://ytiz.xyz',
                'sec-fetch-dest': 'empty',
                'sec-fetch-mode': 'cors',
                'sec-fetch-site': 'cross-site',
                'priority': 'u=4',
                'te': 'trailers'
            },
            data: data,
            responseType: 'arraybuffer'
        };

        const api = await axios.request(config);
        const fileName = `${uuidv4()}.mp3`;
        const filePath = path.join(tmpDir, fileName);
        fs.writeFileSync(filePath, api.data);

        return filePath;
    }
}

module.exports = { ytiz }