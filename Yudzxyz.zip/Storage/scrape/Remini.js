const axios = require("axios");
const FormData = require("form-data");
const { Buffer } = require("buffer");

async function remini(e, r) {
    try {
        const t = require("form-data"),
            a = "https://inferenceengine.vyro.ai/" + r + ".vyro",
            n = new t;
        n.append("image", Buffer.from(e), {
            filename: "enhance_image_body.jpg",
            contentType: "image/jpeg"
        }), n.append("model_version", 1);
        return (await axios.post(a, n, {
            headers: {
                ...n.getHeaders(),
                "User-Agent": "okhttp/4.9.3",
                Connection: "Keep-Alive",
                "Accept-Encoding": "gzip"
            },
            responseType: "arraybuffer",
            timeout: 3e4
        })).data
    }
    catch (e) {
        throw console.error("Error in remini function:", e), e
    }
}

module.exports = { remini };