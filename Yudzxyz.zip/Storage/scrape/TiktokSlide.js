const axios = require('axios');
const cheerio = require('cheerio');

// TIKTOK SLIDE HD FUNCTION
  async function ttslide(t) {
    const e = (await axios.get(`https://dlpanda.com/id?url=${t}&token=G7eRpMaa`)).data,a = cheerio.load(e);
    let s = [],o = [],n ="Jikarinka";a("div.col-md-12 > img").each (((t,e) => { o.push(a(e).attr("src"))})),s.push({creator:n,imgSrc:o});o.map(((t,e) => ({img:t,creator:n})));return s
  }

module.exports = { ttslide };