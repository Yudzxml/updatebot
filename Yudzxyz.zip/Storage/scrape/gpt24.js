const axios = require('axios');

const gpt24 = {
  chatOnly: async (prompt, question) => {
    const data = JSON.stringify({
        "messages": [
            {
                "role": "system",
                "content": prompt
            },
            {
                "role": "user",
                "content": question
            }
        ],
        "stream": false,
        "model": "gpt-4o-mini",
        "temperature": 0.5,
        "presence_penalty": 0,
        "frequency_penalty": 0,
        "top_p": 1,
        "max_tokens": 4000
    });

    const config = {
        method: 'POST',
        url: 'https://gpt24-ecru.vercel.app/api/openai/v1/chat/completions',
        headers: {
            'User-Agent': 'Mozilla/5.0 (Android 10; Mobile; rv:131.0) Gecko/131.0 Firefox/131.0',
            'Accept': 'application/json, text/event-stream',
            'Content-Type': 'application/json',
            'accept-language': 'id-ID',
            'referer': 'https://gpt24-ecru.vercel.app/',
            'origin': 'https://gpt24-ecru.vercel.app',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-origin',
            'priority': 'u=0',
            'te': 'trailers',
            'Cookie': '_ga_89WN60ZK2E=GS1.1.1736208261.1.1.1736208312.0.0.0; _ga=GA1.1.1312319525.1736208262'
        },
        data: data
    };

    const api = await axios.request(config);
    return JSON.stringify(api.data, null, 2);
  },
  chatWithImage: async (prompt, question, imageUrl) => {
    const data = JSON.stringify({
        "messages": [
            {
                "role": "system",
                "content": prompt
            },
            {
                "role": "user",
                "content": [
                    {
                        "type": "text",
                        "text": question
                    },
                    {
                        "type": "image_url",
                        "image_url": {
                            "url": imageUrl
                        }
                    }
                ]
            }
        ],
        "stream": false,
        "model": "gpt-4o-mini",
        "temperature": 0.5,
        "presence_penalty": 0,
        "frequency_penalty": 0,
        "top_p": 1,
        "max_tokens": 4000
    });

    const config = {
        method: 'POST',
        url: 'https://gpt24-ecru.vercel.app/api/openai/v1/chat/completions',
        headers: {
            'User-Agent': 'Mozilla/5.0 (Android 10; Mobile; rv:131.0) Gecko/131.0 Firefox/131.0',
            'Accept': 'application/json, text/event-stream',
            'Content-Type': 'application/json',
            'accept-language': 'id-ID',
            'referer': 'https://gpt24-ecru.vercel.app/',
            'origin': 'https://gpt24-ecru.vercel.app',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-origin',
            'priority': 'u=4',
            'te': 'trailers',
            'Cookie': '_ga_89WN60ZK2E=GS1.1.1736208261.1.1.1736208312.0.0.0; _ga=GA1.1.1312319525.1736208262'
        },
        data: data
    };

    const api = await axios.request(config);
    return JSON.stringify(api.data, null, 2);
  }
}

module.exports = { gpt24 }