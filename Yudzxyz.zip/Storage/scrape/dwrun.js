const axios = require('axios');
const cheerio = require('cheerio');

const dwrun = {
    dl: async function(link) {
        try {
            // Mengambil halaman dari downloader.run
            const { data: api } = await axios.get('https://downloader.run');
            
            // Mengambil token dari halaman yang diambil
            const token = cheerio.load(api)('#token').val();
            
            // Mengirimkan permintaan POST untuk mendapatkan data video
            const { data } = await axios.post('https://downloader.run/wp-json/aio-dl/video-data/', 
                new URLSearchParams({ url: link, token }), {
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                        'User-Agent': 'Postify/1.0.0'
                    }
                }
            );
            
            // Mengembalikan data yang diterima
            return data;
        } catch (error) {
            // Mengembalikan error jika terjadi kesalahan
            return { error: error.response?.data || error.message };
        }
    }
};
module.exports = { dwrun };