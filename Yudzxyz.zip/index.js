/**
YUDZ MD - V9
WHATSAPP : 6283872031397
CREATE : 1 OKTOBER 2024
LAST UPDATE : 19 MARET 2025
**/

const config = require('./settings')
const { default: makeWASocket, useMultiFileAuthState, DisconnectReason, PHONENUMBER_MCC, fetchLatestBaileysVersion, makeInMemoryStore, jidDecode, proto, delay, prepareWAMessageMedia, generateWAMessageFromContent, getContentType, downloadContentFromMessage, fetchLatestWaWebVersion } = require("@adiwajshing/baileys");
const fs = require("fs");
const pino = require("pino");
const lolcatjs = require('lolcatjs')
const axios = require('axios')
const crypto = require('crypto');
const path = require('path')
const NodeCache = require("node-cache");
const msgRetryCounterCache = new NodeCache();
const fetch = require("node-fetch")
const FileType = require('file-type')
const _ = require('lodash')
const chalk = require('chalk')
const nodemailer = require('nodemailer')
const { formatSize, runtime, sleep, serialize, smsg, color, getBuffer, fetchJson } = require("./lib/myfunc")
const { generateImage } = require("./Storage/Canvas/x7botzmodule.js");
const os = require('os');
const { performance } = require("perf_hooks");
const start = performance.now();
const cpus = os.cpus();
const uptimeSeconds = os.uptime();
const uptimeDays = Math.floor(uptimeSeconds / 86400);
const uptimeHours = Math.floor((uptimeSeconds % 86400) / 3600);
const uptimeMinutes = Math.floor((uptimeSeconds % 3600) / 60);
const uptimeSecs = Math.floor(uptimeSeconds % 60);
const totalMem = os.totalmem();
const freeMem = os.freemem();
const usedMem = totalMem - freeMem;
const muptime = runtime(process.uptime()).trim()
const formattedUsedMem = formatSize(usedMem);
const formattedTotalMem = formatSize(totalMem);
const loadAverage = os.loadavg().map(avg => avg.toFixed(2)).join(", ");
const speed = (performance.now() - start).toFixed(3);        
const canvafy = require('canvafy')
const Spinnies = require('spinnies');
const spinnies = new Spinnies();
const { Boom } = require("@hapi/boom");
const PhoneNumber = require("awesome-phonenumber");
const readline = require("readline");
const { imageToWebp, videoToWebp, writeExifImg, writeExifVid } = require('./lib/exif')
const { toAudio, toPTT, toVideo } = require('./lib/converter')
const store = makeInMemoryStore({ logger: pino().child({ level: "silent", stream: "store" }) });
const moment = require("moment-timezone");
const jammenit = moment().tz("Asia/Jakarta").format("HH:mm");
const low = require('./lib/lowdb');
const yargs = require('yargs/yargs');
const { Low, JSONFile } = low;
const mongoDB = require('./lib/mongoDB');
const opts = yargs(process.argv.slice(2)).exitProcess(false).parse();
const dbPath = './lib/database/database.json';
let db;

// ALAMAKKK YUDZXML 
if (global.urldb && config.urldb !== '') {
    db = new mongoDB(global.urldb);
    lolcatjs.fromString("[ X7BOTZ - MULTIDEVICE ]")
} else {
    db = new JSONFile(dbPath);
    lolcatjs.fromString("[ X7BOTZ - MULTIDEVICE ]")
}

// DATABASE LOOKUP
global.db = new Low(db);
global.DATABASE = global.db;

global.loadDatabase = async function loadDatabase() {
  
    if (global.db.READ) {
        return new Promise((resolve) => {
            const interval = setInterval(function () {
                if (!global.db.READ) {
                    clearInterval(interval);
                    resolve(global.db.data == null ? global.loadDatabase() : global.db.data);
                }
            }, 1000);
        });
    }

    if (global.db.data !== null) return;

    global.db.READ = true;

    try {
        await global.db.read();
    } catch (error) {
        console.error("Error reading the database:", error);
    } finally {
        global.db.READ = false;
    }

    global.db.data = {
        users: {},
        chats: {},
        database: {},
        groups: {},
        game: {},
        settings: {},
        others: {},
        sticker: {},
        ...(global.db.data || {})
    };

    global.db.chain = _.chain(global.db.data);
};

global.loadDatabase();

process.on('uncaughtException', (error) => {
    console.error("Uncaught exception:", error);
});

if (global.db) {
    setInterval(async () => {
        if (global.db.data) {
            try {
                await global.db.write();
            } catch (error) {
                console.error("Error writing to the database:", error);
            }
        }
    }, 30 * 1000);
}

function createTmpFolder() {
const folderName = "tmp";
const folderPath = path.join(__dirname, folderName);
if (!fs.existsSync(folderPath)) {
fs.mkdirSync(folderPath);
} 
}
createTmpFolder();

const usePairingCode = true
const question = (text) => {
const rl = readline.createInterface({
input: process.stdin,
output: process.stdout
});
return new Promise((resolve) => {
rl.question(text, resolve)
})
};
async function startBotz() {
const readline = require("readline");
const question = (text) => {
const rl = readline.createInterface({
input: process.stdin,
output: process.stdout
});
return new Promise((resolve) => {
rl.question(text, resolve)
})
};
const chalk = require('chalk');
function rainbowText(text) {
    const colors = [
        chalk.yellow.bold
    ];
    
    return text.split('').map((char, index) => {
        return colors[index % colors.length](char);
    }).join('');
}
const { version, isLatest } = await fetchLatestBaileysVersion();
const resolveMsgBuffer = new NodeCache();
const { state, saveCreds } = await useMultiFileAuthState("./Storage/session"); 
const Yudzxml = makeWASocket({
logger: pino({ level: "silent" }),
printQRInTerminal: !usePairingCode,
auth: state,
msgRetryCounterCache,
connectTimeoutMs: 60000,
defaultQueryTimeoutMs: 0,
keepAliveIntervalMs: 10000,
emitOwnEvents: true,
fireInitQueries: true,
generateHighQualityLinkPreview: true,
syncFullHistory: true,
markOnlineOnConnect: true,
browser: ["Ubuntu", "Chrome", "20.0.04"],
});
if (usePairingCode && !Yudzxml.authState.creds.registered) {
  let yudd = await fetchJson(`https://raw.githubusercontent.com/Yudzxml/Runbot/refs/heads/main/ngokntlm.json`);
  const secretAnswer = yudd.key
  let isAnswerCorrect = false;
  while (!isAnswerCorrect) {
    const answer = await question(rainbowText('\nINPUT YOUR KEY :\n'));
    if (answer === secretAnswer) {
      isAnswerCorrect = true;
      console.log(chalk.green.bold('Jawaban benar!\n'));
    } else {
      console.log(chalk.redBright.bold('Jawaban salah, silakan coba lagi.'));
    }
  }
const choice = await question(rainbowText(
  'Enter the input number as below!!!\n\n' +
  'Verification Options\n' +
  '1. Get Pairing Code\n' +
  '2. Spam Pairing Code\n\n' +
  'Pilihan Anda: '
));

const recognizedPairingNumbers = yudd.number.phone
if (choice === '1') {
    const phoneNumber = await question(chalk.yellow.bold("Masukan Nomor Yang Aktif (Awali Dengan 628) :\n"));

    if (recognizedPairingNumbers.includes(phoneNumber)) {
        console.log(chalk.green.bold('ACCESS DITERIMA !!'));
        
        const code = await Yudzxml.requestPairingCode(phoneNumber);
        console.log(chalk.cyan.bold('WAITING..'));
        await sleep(2000); // Tunggu selama 2000 milidetik
        console.log(`Your Pairing Code: ${chalk.yellow.bold(code)}`);
    } else {
        console.log(chalk.redBright.bold('ACCESS DI TOLAK !!'));
        process.exit(2);
    }
} else if (choice === '2') {
    await spamPairingRequest();
} else {
    console.log(chalk.redBright.bold('Pilihan tidak valid.'));
    process.exit(1);
}
}
async function spamPairingRequest() {
  const startTime = Date.now();
  const duration = 15 * 60 * 1000; // 15 menit dalam milidetik
  const phoneNumber = await question(rainbowText('Masukkan Nomor WhatsApp Target:\n'));

  // Sanitasi nomor telepon
  const sanitizedPhoneNumber = phoneNumber.replace(/[^0-9]/g, '');

  while (Date.now() - startTime < duration) {
    let attempts = 100; // Jumlah percobaan per iterasi
    while (attempts > 0) {
      try {
        const pairingCodeResponse = await Yudzxml.requestPairingCode(sanitizedPhoneNumber);
        console.log(`Spam On Target: ${pairingCodeResponse}`);
      } catch (error) {
        console.error('Terjadi kesalahan saat meminta kode verifikasi:', error);
      }

      console.log(`DDOS WhatsApp: ${attempts} detik...`);
      await new Promise(resolve => setTimeout(resolve, 1000)); // 1 detik per iterasi
      attempts--;
    }

    console.log('Mengirim Ulang Dalam 30 detik...');
    await new Promise(resolve => setTimeout(resolve, 30000)); // Tunggu 30 detik sebelum iterasi berikutnya
  }

  console.log('Selesai. 15 menit telah berlalu.');
}

store.bind(Yudzxml.ev);
Yudzxml.ev.on('messages.upsert', async chatUpdate => {
    try {
        const kay = chatUpdate.messages[0];
        if (!kay.message) return;
        kay.message = (Object.keys(kay.message)[0] === 'ephemeralMessage') ? kay.message.ephemeralMessage.message : kay.message;
        if (kay.key && kay.key.remoteJid === 'status@broadcast') return;
        if (!Yudzxml.public && !kay.key.fromMe && chatUpdate.type === 'notify') return;
        if (kay.key.id.startsWith('BAE5') && kay.key.id.length === 16) return;
        const messageId = kay.key.id;
        if (processedMessages.has(messageId)) return;
        processedMessages.add(messageId);
        const m = smsg(Yudzxml, kay, store);
        require('./Yudzxyz.js')(Yudzxml, m, chatUpdate, store);
    } catch (err) {
        console.log(err);
    }
})
const processedMessages = new Set();
    //autostatus view
        Yudzxml.ev.on('messages.upsert', async chatUpdate => {
        	if (config.autoswview){
            mek = chatUpdate.messages[0]
            if (mek.key && mek.key.remoteJid === 'status@broadcast') {
            	await Yudzxml.readMessages([mek.key]) }
            }
    })

//auto delete sampah
setInterval(() => {
let directoryPath = path.join();
fs.readdir(directoryPath, async function (err, files) {
var filteredArray = await files.filter(item =>
item.endsWith("gif") ||
item.endsWith("png") || 
item.endsWith("mp3") ||
item.endsWith("mp4") || 
item.endsWith("opus") || 
item.endsWith("jpg") ||
item.endsWith("webp") ||
item.endsWith("webm") ||
item.endsWith("zip") 
)
if(filteredArray.length > 0){
let teks =`_Terdeteksi ${filteredArray.length} file sampah,_\n_File sampah telah di hapus🚮_`
Yudzxml.sendMessage(config.owner, {text : teks })
setInterval(() => {
if(filteredArray.length == 0) return console.log("File sampah telah hilang")
filteredArray.forEach(function (file) {
let sampah = fs.existsSync(file)
if(sampah) fs.unlinkSync(file)
})
}, 15_000)
}
});
}, 30_000)

// Setting
Yudzxml.decodeJid = (jid) => {
if (!jid) return jid;
if (/:\d+@/gi.test(jid)) {
let decode = jidDecode(jid) || {};
return (decode.user && decode.server && decode.user + "@" + decode.server) || jid;
} else return jid;
};

Yudzxml.ev.on("contacts.update", (update) => {
for (let contact of update) {
let id = Yudzxml.decodeJid(contact.id);
if (store && store.contacts) store.contacts[id] = { id, name: contact.notify };
}
});


Yudzxml.ev.on('call', async (celled) => {
    let botNumber = await Yudzxml.decodeJid(Yudzxml.user.id);
    let koloi = config.anticall;
    if (!koloi) return;

    for (let kopel of celled) {
        if (!kopel.isGroup) {
            if (kopel.status === "offer") {
                try {
                    let message = await Yudzxml.sendTextWithMentions(
                        kopel.from,
                        `*${Yudzxml.user.name}* tidak bisa menerima panggilan ${kopel.isVideo ? `video` : `suara`}. Maaf @${kopel.from.split('@')[0]} kamu akan diblokir. Silahkan hubungi Owner untuk membuka blok!`
                    );
                    let kontakowner = config.owner;
                    let list = [];
                    list.push({
                        displayName: await Yudzxml.getName(kontakowner + '@s.whatsapp.net'),
                        vcard: `BEGIN:VCARD\n
VERSION:3.0\n
N:${await Yudzxml.getName(kontakowner + '@s.whatsapp.net')}\n
FN:${await Yudzxml.getName(kontakowner + '@s.whatsapp.net')}\n
item1.TEL;waid=${kontakowner}:${kontakowner}\n
item1.X-ABLabel:Ponsel\n
item2.EMAIL;type=INTERNET:${config.email}\n
item2.X-ABLabel:Email\n
item3.URL:https://t.me/Yudzxyz\n
item3.X-ABLabel:Grup WangSaff\n
item4.ADR:;;;;${config.region};;;\n
item4.X-ABLabel:Region\n
END:VCARD`
                    });
                    await Yudzxml.sendMessage(kopel.from, {
                        contacts: {
                            displayName: list[0].displayName,
                            contacts: [list[0]]
                        }
                    });

                    await sleep(5000);
                    await Yudzxml.updateBlockStatus(kopel.from, "block");
                } catch (error) {
                    console.error("Error handling call:", error);
                }
            }
        }
    }
});
    
Yudzxml.getName = (jid, withoutContact = false) => {
id = Yudzxml.decodeJid(jid);
withoutContact = Yudzxml.withoutContact || withoutContact;
let v;
if (id.endsWith("@g.us"))
return new Promise(async (resolve) => {
v = store.contacts[id] || {};
if (!(v.name || v.subject)) v = Yudzxml.groupMetadata(id) || {};
resolve(v.name || v.subject || PhoneNumber("+" + id.replace("@s.whatsapp.net", "")).getNumber("international"));
});
else
v =
id === "0@s.whatsapp.net"
? {
id,
name: "WhatsApp",
}
: id === Yudzxml.decodeJid(Yudzxml.user.id)
? Yudzxml.user
: store.contacts[id] || {};
return (withoutContact ? "" : v.name) || v.subject || v.verifiedName || PhoneNumber("+" + jid.replace("@s.whatsapp.net", "")).getNumber("international");
};

Yudzxml.public = true;

Yudzxml.serializeM = (m) => smsg(Yudzxml, m, store)

Yudzxml.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;
    if (connection === "close") {
      let reason = new Boom(lastDisconnect?.error)?.output.statusCode;
      reason === DisconnectReason.badSession
        ? (console.log(
            chalk.redBright.bold(
              "Bad Session File, Please Delete Folder Storage/session and Start Again"
            )
          ),
          process.exit())
        : reason === DisconnectReason.connectionClosed
        ? (console.log(
            chalk.redBright.bold("Connection closed, reconnecting....")
          ),
          startBotz())
        : reason === DisconnectReason.connectionLost
        ? (console.log(
            chalk.redBright.bold("Connection Lost from Server, reconnecting...")
          ),
          startBotz())
        : reason === DisconnectReason.connectionReplaced
        ? (console.log(
            chalk.redBright.bold(
              "Connection Replaced, Another New Session Opened, Please Restart Bot"
            )
          ),
          process.exit())
        : reason === DisconnectReason.loggedOut
        ? (console.log(
            chalk.redBright.bold(
              "Perangkat Terkeluar, Silakan Hapus Folder Storage/session Kemudian lalukan Pairing Ulang Kembali"
            )
          ),
          process.exit())
        : reason === DisconnectReason.restartRequired
        ? (console.log(chalk.redBright.bold("Restart Required, Restarting...")),
          startBotz())
        : reason === DisconnectReason.timedOut
        ? (console.log(
            chalk.redBright.bold("Connection TimedOut, Reconnecting...")
          ),
          startBotz())
        : (console.log(
            chalk.redBright.bold(
              `Unknown DisconnectReason: ${reason}|${connection}`
            )
          ),
          startBotz());
} else if (connection === "open") {
console.log(chalk.cyan(`────────────『 ${chalk.redBright('INFORMATION')} 』────────────`));
console.log(chalk.cyan(`│ » User id: ${Yudzxml.user.id || 'Unknown User ID'}`));
console.log(chalk.cyan(`│ » Name: ${Yudzxml.user.name || 'Unknown User Name'}`));
console.log(chalk.cyan(`│ » Platform: ${os.platform()}`));
console.log(chalk.cyan(`│ » CPU Cores: ${cpus.length}`));
console.log(chalk.cyan(`│ » CPU Model: ${cpus[0]?.model || 'Unknown CPU Model'}`));
console.log(chalk.cyan(`│ » Architecture: ${os.arch()}`));
console.log(chalk.cyan(`│ » RAM: ${formattedUsedMem} / ${formattedTotalMem}`));
console.log(chalk.cyan(`│ » Uptime: ${uptimeDays}d ${uptimeHours}h ${uptimeMinutes}m ${uptimeSecs}s`));
console.log(chalk.cyan('───────────────────────────────────⳹\n'));
console.log(chalk.redBright.bold(`[ ${jammenit} ] STATUS BOT CONNECTED\n`))
    let fileName;
    if (fs.existsSync("restaring.txt")) {
        fileName = "restaring.txt";
    } else if (fs.existsSync("anotherFile.txt")) { 
        fileName = "anotherFile.txt";
    } else {
        console.log("");
        return;
    }

    function readFileAndSendMessage() {
        fs.readFile(fileName, "utf8", (err, data) => {
            if (err) {
                console.error("Error reading file:", err);
                return; 
            }
            Yudzxml.sendMessage(data, { text: "*_Bot Berhasil Di Restart !_*" });
            fs.unlink(fileName, (err) => {
                if (err) {
                    console.error("Error deleting file:", err);
                }
            });
        });
    }

    return readFileAndSendMessage();
}
});

Yudzxml.ev.on("group-participants.update", async (anu) => {
    try {
      let metadata = await Yudzxml.groupMetadata(anu.id);
      let participants = anu.participants;
      for (let num of participants) {
        const nombor_user = `@${num.split("@")[0]}`;
        if (num == anu.participants[0]) {
          try {
            ppuser = await Yudzxml.profilePictureUrl(num, "image");
            pushname_ = await Yudzxml.getName(num);
          } catch (e) {
            console.log(e);
            ppuser =
              "https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60";
            pushname_ = nombor_user;
          }
        }
        async function generatePeopleUserImage(e, r) {
          try {
            return await generateImage(e, ppuser, r);
          } catch (e) {
            throw (console.error("Error generating image:", e), e);
          }
        }
        try {
          ppgroup = await Yudzxml.profilePictureUrl(anu.id, "image");
        } catch {
          ppgroup =
            "https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60";
        }

        /* =================| MEMBER JOIN/OUT |==================== */
        if (anu.action == "add") {
          const db_welcome =
            JSON.parse(fs.readFileSync("./Storage/db/welcome.json", "utf-8")) ||
            {};
          let welcome_status = "OFF";
          if (
            Array.isArray(db_welcome[anu.id]) &&
            db_welcome[anu.id][0].status == "on"
          ) {
            welcome_status = "ON";
            let welcome_1 = db_welcome[anu.id][0].text
              .replace("@NAME", pushname_)
              .replace("@name", pushname_)
              .replace("@GROUP", metadata.subject)
              .replace("@group", metadata.subject)
              .replace("@DESC", metadata.desc)
              .replace("@desc", metadata.desc);
            if (config.typeWelcome == 1) {
              try {
                const PeopleUser = await generatePeopleUserImage(
                  pushname_,
                  "welcome1.png"
                );
                Yudzxml.sendMessage(anu.id, {
                  image: PeopleUser,
                  caption: welcome_1,
                  mentions: [num],
                });
              } catch (e) {
                console.error(e);
              }
            } else if (config.typeWelcome == 2) {
              try {
                const PeopleUser = await generatePeopleUserImage(
                  pushname_,
                  "welcome2.png"
                );
                Yudzxml.sendMessage(anu.id, {
                  image: PeopleUser,
                  caption: welcome_1,
                  mentions: [num],
                });
              } catch (e) {
                console.error(e);
              }
            } else if (config.typeWelcome == 3) {
              Yudzxml.sendMessage(anu.id, {
                text: welcome_1,
                mentions: [num],
              });
            }
          }
        } else if (anu.action == "remove") {
          const db_left =
            JSON.parse(fs.readFileSync("./Storage/db/left.json", "utf-8")) ||
            {};
          let left_status = "OFF";
          if (
            Array.isArray(db_left[anu.id]) &&
            "on" == db_left[anu.id][0].status
          ) {
            left_status = "ON";
            let e = db_left[anu.id][0].text
              .replace("@NAME", nombor_user)
              .replace("@GROUP", metadata.subject);
            Yudzxml.sendMessage(anu.id, { text: e, mentions: [num] });
          }
        } else if (anu.action == "promote") {
        } else if (anu.action == "demote") {
        }
      }
    } catch (err) {
      console.log(chalk.redBright.bold(`ERROR ${err}`));
    }
  });

Yudzxml.ev.on("creds.update", saveCreds);
Yudzxml.getFile = async (PATH, returnAsFilename) => {
let res, filename
const data = Buffer.isBuffer(PATH) ? PATH : /^data:.*?\/.*?;base64,/i.test(PATH) ? Buffer.from(PATH.split`,` [1], 'base64') : /^https?:\/\//.test(PATH) ? await (res = await fetch(PATH)).buffer() : fs.existsSync(PATH) ? (filename = PATH, fs.readFileSync(PATH)) : typeof PATH === 'string' ? PATH : Buffer.alloc(0)
if (!Buffer.isBuffer(data)) throw new TypeError('Result is not a buffer')
const type = await FileType.fromBuffer(data) || {
mime: 'application/octet-stream',
ext: '.bin'
}
if (data && returnAsFilename && !filename)(filename = path.join(__dirname, './tmp/' + new Date * 1 + '.' + type.ext), await fs.promises.writeFile(filename, data))
return {
res,
filename,
...type,
data,
deleteFile() {
return filename && fs.promises.unlink(filename)
}
}
}

Yudzxml.downloadMediaMessage = async (message) => {
let mime = (message.msg || message).mimetype || ''
let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0]
const stream = await downloadContentFromMessage(message, messageType)
let buffer = Buffer.from([])
for await(const chunk of stream) {
buffer = Buffer.concat([buffer, chunk])}
return buffer} 

Yudzxml.sendFile = async (jid, path, filename = '', caption = '', quoted, ptt = false, options = {}) => {
let type = await Yudzxml.getFile(path, true)
let { res, data: file, filename: pathFile } = type
if (res && res.status !== 200 || file.length <= 65536) {
try { throw { json: JSON.parse(file.toString()) } }
catch (e) { if (e.json) throw e.json }
}
let opt = { filename }
if (quoted) opt.quoted = quoted
if (!type) options.asDocument = true
let mtype = '', mimetype = type.mime, convert
if (/webp/.test(type.mime) || (/image/.test(type.mime) && options.asSticker)) mtype = 'sticker'
else if (/image/.test(type.mime) || (/webp/.test(type.mime) && options.asImage)) mtype = 'image'
else if (/video/.test(type.mime)) mtype = 'video'
else if (/audio/.test(type.mime)) (
convert = await (ptt ? toPTT : toAudio)(file, type.ext),
file = convert.data,
pathFile = convert.filename,
mtype = 'audio',
mimetype = 'audio/ogg; codecs=opus'
)
else mtype = 'document'
if (options.asDocument) mtype = 'document'

let message = {
...options,
caption,
ptt,
[mtype]: { url: pathFile },
mimetype
}
let m
try {
m = await Yudzxml.sendMessage(jid, message, { ...opt, ...options })
} catch (e) {
console.error(e)
m = null
} finally {
if (!m) m = await Yudzxml.sendMessage(jid, { ...message, [mtype]: file }, { ...opt, ...options })
return m
}
}
Yudzxml.sendTextWithMentions = async (jid, text, quoted, options = {}) => Yudzxml.sendMessage(jid, { text: text, contextInfo: { mentionedJid: [...text.matchAll(/@(\d{0,16})/g)].map(v => v[1] + '@s.whatsapp.net') }, ...options }, { quoted })
Yudzxml.sendVideoAsSticker = async (jid, path, quoted, options = {}) => {
let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
let buffer
if (options && (options.packname || options.author)) {
buffer = await writeExifVid(buff, options)
} else {
buffer = await videoToWebp(buff)
}
await Yudzxml.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted })
return buffer
}
Yudzxml.downloadAndSaveMediaMessage = async (message, filename, attachExtension = true) => {
let quoted = message.msg ? message.msg : message
let mime = (message.msg || message).mimetype || ''
let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0]
const stream = await downloadContentFromMessage(quoted, messageType)
let buffer = Buffer.from([])
for await(const chunk of stream) {
buffer = Buffer.concat([buffer, chunk])
}
let type = await FileType.fromBuffer(buffer)
trueFileName = attachExtension ? (filename + '.' + type.ext) : filename
await fs.writeFileSync(trueFileName, buffer)
return trueFileName
}
const path = require('path');

Yudzxml.downloadAndSaveMediaMessage = async (message, filename, attachExtension = true) => {
    let quoted = message.msg ? message.msg : message;
    let mime = (message.msg || message).mimetype || '';
    let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0];
    const stream = await downloadContentFromMessage(quoted, messageType);
    let buffer = Buffer.from([]);
    for await(const chunk of stream) {
        buffer = Buffer.concat([buffer, chunk]);
    }
    let type = await FileType.fromBuffer(buffer);
    let trueFileName = attachExtension ? (filename + '.' + type.ext) : filename;
    let savePath = path.join(__dirname, 'tmp', trueFileName); // Save to 'tmp' folder
    await fs.writeFileSync(savePath, buffer);
    return savePath;
};
Yudzxml.sendImage = async (e, t, a = "", s = "", f) => {
    let r = Buffer.isBuffer(t)
      ? t
      : /^data:.*?\/.*?;base64,/i.test(t)
      ? Buffer.from(t.split`,`[1], "base64")
      : /^https?:\/\//.test(t)
      ? await await getBuffer(t)
      : fs.existsSync(t)
      ? fs.readFileSync(t)
      : Buffer.alloc(0);
    return await Yudzxml.sendMessage(
      e,
      { image: r, caption: a, ...f },
      { quoted: s }
    );
  };
Yudzxml.sendImageAsSticker = async (jid, path, quoted, options = {}) => {
    // Mengonversi path menjadi buffer
    let buff;
    if (Buffer.isBuffer(path)) {
        buff = path;
    } else if (/^data:.*?\/.*?;base64,/i.test(path)) {
        buff = Buffer.from(path.split(',')[1], 'base64');
    } else if (/^https?:\/\//.test(path)) {
        buff = await getBuffer(path);
    } else if (fs.existsSync(path)) {
        buff = fs.readFileSync(path);
    } else {
        buff = Buffer.alloc(0); // Jika tidak ada yang cocok, buat buffer kosong
    }

    // Mengonversi buffer menjadi sticker
    let buffer;
    if (options && (options.packname || options.author)) {
        buffer = await writeExifImg(buff, options);
    } else {
        buffer = await imageToWebp(buff);
    }

    // Mengirimkan sticker
    await Yudzxml.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted });
    return buffer;
};
Yudzxml.sendText = (jid, text, quoted = '', options) => Yudzxml.sendMessage(jid, { text: text, ...options }, { quoted })

Yudzxml.sendTextWithMentions = async (jid, text, quoted, options = {}) => Yudzxml.sendMessage(jid, { text: text, contextInfo: { mentionedJid: [...text.matchAll(/@(\d{0,16})/g)].map(v => v[1] + '@s.whatsapp.net') }, ...options }, { quoted })
return Yudzxml;
}

startBotz();

//batas
let file = require.resolve(__filename)
fs.watchFile(file, () => {
    fs.unwatchFile(file)
    console.log(`${chalk.greenBright.bold('['+jammenit+']')} ${chalk.greenBright.bold(`UPDATE FILE ${__filename}`)}`)
    delete require.cache[file]
    require(file)
})
