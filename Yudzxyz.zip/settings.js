/**
YUDZ MD - V9
WHATSAPP : 6283872031397
CREATE : 1 OKTOBER 2024
LAST UPDATE : 28 JANUARI 2025
**/

const fs = require('fs')
const chalk = require('chalk')
const moment = require('moment-timezone')
const hariini = moment.tz('Asia/Jakarta').format('dddd, DD MMMM YYYY')	
const time = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('HH:mm:ss z')
const jammenit = moment().tz('Asia/Jakarta').format('HH:mm');

const config = {
  owner: '6283872031397',
  region: 'Indonesia',
  ownername: '❃ ʏᴜᴅᴢ - ᴍᴜʟᴛɪᴅᴇᴠɪᴄᴇ',
  namestore: 'YUDZXML STORE 77',
  email: 'yudaaryaardhana1122@gmail.com',
  botname: 'X7BOTZ - MD V9',
  packname: '❃ ʏᴜᴅᴢ - ᴍᴜʟᴛɪᴅᴇᴠɪᴄᴇ',
  author: `Date: ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}\nTelegram: @Yudzxzy\nSticker: By Yudzxml`,
  themeemoji: '🍁',
  urldb: '',// KOSONGIN
  saluran: 'https://whatsapp.com/channel/0029VaQfuS74dTnEv0b6hA1g',
  grup: 'https://chat.whatsapp.com/BiY2EOldsEK0xXzxJP1Lm9',
  idch: '120363263460724112@newsletter',
  prefix_custom: ['/','!','.','#','&'],
  resetlimit: 1440,// MENIT
  sleep_game: 60000,// 60 DETIK
  MoneyMenangGame: 20,// 20 MONEY
  ratelimiter: 3,// 5 DETIK
  typeWelcome: 1,// TYP 1, TYPE 2, TYP 3
  botDestination: 'group',// private / group / both
  autojpm: false,
  autoshalat: true,
  autoRead: true,
  prefix: true,
  autoswview: true,
  public: true,
  antitoxic: true,
  anticall: true,
  AutoLevelUp: true,
  Autobackup: true,
  autoreboot: true,
  waktureboot: 360,// MENIT
  icon_on: '🟢',
  icon_off: '🟡',
  thumbnail: {
    qris: [
'https://raw.githubusercontent.com/Yudzxml/Uploader/main/Yudzxml524.jpg'
], // QRIS LU GANTI
    allmenu: [
'https://raw.githubusercontent.com/Yudzxml/Uploader/main/Yudzxml785.mp4'
], // VIDIO ALLMENU
    imagereply: [
"https://raw.githubusercontent.com/Yudzxml/Uploader/main/Yudzxml45.jpg",
"https://raw.githubusercontent.com/Yudzxml/Uploader/main/Yudzxml832.jpg",
"https://raw.githubusercontent.com/Yudzxml/Uploader/main/Yudzxml326.jpg",
"https://raw.githubusercontent.com/Yudzxml/Uploader/main/Yudzxml920.jpg",
"https://raw.githubusercontent.com/Yudzxml/Uploader/main/Yudzxml963.jpg",
"https://raw.githubusercontent.com/Yudzxml/Uploader/main/Yudzxml732.jpg"
],// FOTO FAKE REPLY 
     imagemenu: [
"https://raw.githubusercontent.com/Yudzxml/Uploader/main/Yudzxml914.jpg",
"https://raw.githubusercontent.com/Yudzxml/Uploader/main/Yudzxml296.jpg",
"https://raw.githubusercontent.com/Yudzxml/Uploader/main/Yudzxml304.jpg",
"https://raw.githubusercontent.com/Yudzxml/Uploader/main/Yudzxml512.jpg",
"https://raw.githubusercontent.com/Yudzxml/Uploader/main/Yudzxml839.jpg",
"https://raw.githubusercontent.com/Yudzxml/Uploader/main/Yudzxml536.jpg"
],// FOTO ALLMENU
     audio: [
"https://files.catbox.moe/zwn8tr.mp3",
"https://files.catbox.moe/7evq63.mp3",
"https://files.catbox.moe/kpggzt.mp3",
"https://files.catbox.moe/aot9pk.mp3",
"https://autoresbot.com/tmp_files/ade17287-b1ab-4ca8-95f6-6ffe9341e13c.mp3",
"https://files.catbox.moe/uitc67.mp3",
"https://files.catbox.moe/t5x904.mp3"
]// AUDIO MENU
},
apikey: {
  auto  : 'https://api.autoresbot.com',// BIARIN
  res   : 'd79b5492b3e840d089939fcf',
  res2  : 'APIKEY_MIKUBOT',// RES 1 DAN 2 AMBIL DI WEB AUTORESBOT
  api   : 'https://api.shannz.work.gd',// BIARIN
  key   : 'yudz',// BELI DI SHANZZ SILAHKAN KUNJUNGIN WEB https://api.shannz.work.gd
  beta  : 'https://api.betabotz.eu.org',// BIARIM
  botz  : 'APIKEY_YUDZXML'// BELI DI BETABOTZ SILHKAN CEK WEB NYA https://api.betabotz.eu.org
}, 
panel: { 
  plta: '',
  pltc: '',
  domain: ''
},
subdomain: {
  domain: '',
  zone: '',
  token: '',
  domain2: '',
  zone2: '',
  token2: '',
  domain3: '',
  zone3: '',
  token3: '',
  domain4: '',
  zone4: '',
  token4: '',
  domain5: '',
  zone5: '',
  token5: ''
},
do: {
  api_token: ''// API TOKEN DIGITAL OCEAN
},
mess: {
  success: '*😋 ᴅᴏɴᴇ ᴅᴇꜱᴜᴜ ~*',
  premium: '_*ꜰɪᴛᴜʀ ᴏɴʟʏ ᴜꜱᴇʀ ᴘʀᴇᴍɪᴜᴍ*_\n*_ʙᴜʏ ᴘʀᴇᴍɪᴜᴍ ꜰᴏʀ ᴀᴄᴄᴇꜱꜱ ꜰɪᴛᴜʀ, ʏᴏᴜ ᴄᴀɴ ᴛʏᴘᴇ .ʙᴜʏᴘʀᴇᴍ, ᴜɴᴛᴜᴋ ᴍᴇʟɪʜᴀᴛ ʟɪꜱᴛ ʜᴀʀɢᴀ ᴍᴇᴍʙᴇʀ ᴘʀᴇᴍɪᴜᴍ_*',
  admin: '_*ᴏɴʟʏ ᴀᴅᴍɪɴ !!*_',
  botNotAdmin: '*_ᴊᴀᴅɪᴋᴀɴ ʙᴏᴛ ᴀᴅᴍɪɴ ᴜɴᴛᴜᴋ ᴍᴇɴɢɢᴜɴᴀᴋᴀɴ ꜰɪᴛᴜʀ ɪɴɪ !!_*',
  userNotAdmin: '*_ᴋᴀᴍᴜ ɪᴛᴜ ʙᴜᴋᴀɴ ᴀᴅᴍɪɴ !!_*',
  urlnotvalid: '*_ʟɪɴᴋ ᴛɪᴅᴀᴋ ᴠᴀʟɪᴅ/ꜱᴀʟᴀʜ!!_*',
  owner: '*_ᴏɴʟʏ ᴏᴡɴᴇʀ !!_*',
  group: '*_ᴏɴʟʏ ɢʀᴜᴘ ᴄʜᴀᴛ !!_*',
  private: '*_ᴏɴʟʏ ᴘʀɪᴠᴀᴛᴇ ᴄʜᴀᴛ !!_*',
  wait: '_*ᴡᴀɪᴛɪɴɢ...*_',    
  error: '_*ꜰɪᴛᴜʀ ꜱᴇᴅᴀɴɢ ᴇʀʀᴏʀ !!*_',
  register: 'ᴍᴀᴀꜰ ᴋᴀᴋ, ᴋᴀᴍᴜ ʙᴇʟᴜᴍ ᴛᴇʀᴅᴀꜰᴛᴀʀ ᴅɪ ᴅᴀᴛᴀʙᴀꜱᴇ ꜱɪʟᴀʜᴋᴀɴ ᴅᴀꜰᴛᴀʀ ᴛᴇʀʟᴇʙɪʜ ᴅᴀʜᴜʟᴜ ᴅᴇɴɢᴀɴ ᴍᴇɴɢᴇᴛɪᴋ .ᴅᴀꜰᴛᴀʀ',
  ban: 'ɴᴏᴍᴏʀ ᴀɴᴅᴀ ᴛᴇʟᴀʜ ᴅɪʙᴀɴɴᴇᴅ ᴏʟᴇʜ ᴏᴡɴᴇʀ ᴅᴀɴ ᴀɴᴅᴀ ᴅɪʟᴀʀᴀɴɢ ᴍᴇɴɢɢᴜɴᴀᴋᴀɴ ꜱᴇᴍᴜᴀ ꜰɪᴛᴜʀ ʙᴏᴛ ᴜɴᴛᴜᴋ ꜱᴇᴍᴇɴᴛᴀʀᴀ ᴡᴀᴋᴛᴜ!!'
},
singlemess: {
  open_grub: "_*ɢʀᴏᴜᴘ ʙᴇʀʜᴀꜱɪʟ ᴅɪʙᴜᴋᴀ ᴛᴜᴀɴ*_ 「 🔓 」",
  close_grub: "_*ɢʀᴏᴜᴘ ʙᴇʀʜᴀꜱɪʟ ᴅɪᴛᴜᴛᴜᴘ ᴛᴜᴀɴ*_ 「 🔒 」",
  kickmember: "_*ʙᴇʀʜᴀꜱɪʟ ᴍᴇɴɢᴇʟᴜᴀʀᴋᴀɴ ᴅᴀʀɪ ɢʀᴜᴘ*_",
  antilinkv1_detek: "_*ᴀɴᴛɪʟɪɴᴋ ᴅᴇᴛᴇᴄᴛɪᴏɴ*_ 「 🚫 」",
  antilinkv2_dete: "_*ᴀɴᴛɪʟɪɴᴋ ᴅᴇᴛᴇᴄᴛɪᴏɴ*_ 「 🚫 」",
  antilinkv3_detek: "_*ᴀɴᴛɪʟɪɴᴋ ᴅᴇᴛᴇᴄᴛɪᴏɴ*_ 「 🚫 」",
  antilinkwa_detek: "_*ᴀɴᴛɪʟɪɴᴋ ᴡᴀ ᴅᴇᴛᴇᴄᴛɪᴏɴ*_ 「 🚫 」",
  antilinkwa2_detek: "_*ᴀɴᴛɪʟɪɴᴋ ᴡᴀ ᴅᴇᴛᴇᴄᴛɪᴏɴ*_ 「 🚫 」",
  antigame: "「 🚫 」 *_ꜰɪᴛᴜʀ ɢᴀᴍᴇ ᴛᴇʟᴀʜ ᴅɪᴍᴀᴛɪᴋᴀɴ ᴜɴᴛᴜᴋ ᴍᴇɴɢʜɪɴᴅᴀʀɪ ꜱᴘᴀᴍ ʙᴇʀʟᴇʙɪʜ, ᴍᴏʜᴏɴ ᴍᴀᴀꜰ ʏᴀ ᴋᴀᴋ..._",
  antispam1: "「 🚫 」 _*ꜱᴘᴀᴍ ᴅᴇᴛᴇᴄᴛɪᴏɴ*_",
  antispam2: "「 🚫 」 *_ᴘᴇʀɪɴɢᴀᴛᴀɴ ᴛᴇʀᴀᴋʜɪʀ!!_*\nᴋᴀᴍᴜ ᴀᴋᴀɴ ᴅɪᴋɪᴄᴋ ᴊɪᴋᴀ ᴍᴇɴɢɪʀɪᴍ ꜱᴘᴀᴍ ᴄʜᴀᴛ ʟᴀɢɪ!!!",
  antisekalilihat: "「 🚫 」 _*ᴀɴᴛɪ 1x ᴅɪʟɪʜᴀᴛ ᴅᴇᴛᴇᴄᴛɪᴏɴ*_",
  antibot_detek: '「 🚫 」 *_ᴀɴᴏᴛʜᴇʀ ʙᴏᴛ ᴅᴇᴛᴇᴄᴛɪᴏɴ_*\nᴍᴏʜᴏɴ ᴍᴀᴀꜰ ᴋᴀᴍᴜ ᴀᴋᴀɴ ꜱᴀʏᴀ ᴋɪᴄᴋ',
  antibadword: '「 🚫 」 *_ɪɴɪ ᴀᴅᴀʟᴀʜ ᴘᴇʀɪɴɢᴀᴛᴀɴ ᴛᴇʀᴀᴋʜɪʀ!!_*\ɴᴋᴀᴍᴜ ᴀᴋᴀɴ ꜱᴀʏᴀ ᴋɪᴄᴋ ᴊɪᴋᴀ ᴍᴇɴɢɢᴜɴᴀᴋᴀɴ/ᴍᴇɴɢɪʀɪᴍ ᴋᴀᴛᴀ² ᴛᴇʀʟᴀʀᴀɴɢ !!',
  antivirtex: '「 🚫 」 *_ᴀɴᴛɪ ᴠɪʀᴛᴇx ᴅᴇᴛᴇᴄᴛɪᴏɴ_*\nᴍᴏʜᴏɴ ᴍᴀᴀꜰ ᴋᴀᴍᴜ ᴀᴋᴀɴ ᴅɪ ᴋɪᴄᴋ ᴅᴀʀɪ ɢʀᴜᴘ',
  unmute: '*_ʙᴏᴛ ʙᴇʀʜᴀꜱɪʟ ᴅɪ ᴜɴᴍᴜᴛᴇ ᴅɪ ɢʀᴜᴘ ɪɴɪ_*',
  mute: '*_ʙᴏᴛ ʙᴇʀʜᴀꜱɪʟ ᴅɪᴍᴜᴛᴇ ᴅɪ ɢʀᴜᴘ ɪɴɪ_*'
},
};

module.exports = config;

let file = require.resolve(__filename)
fs.watchFile(file, () => {
    fs.unwatchFile(file)
    console.log(`${chalk.greenBright.bold('[ '+jammenit+' ]')} ${chalk.greenBright.bold(`UPDATE FILE ${__filename}`)}`)
    delete require.cache[file]
    require(file)
})
