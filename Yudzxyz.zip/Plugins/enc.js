const fs = require('fs');
const path = require('path');
const JavaScriptObfuscator = require('javascript-obfuscator');

module.exports = {
  command: ['encskrip', 'obfuscator', 'encrypt', 'enc'],
  operate: async (context) => {
    const {
      m, text, reply, isDocument, quoted, isRegistered,
      MinLimit, loading, Yudzxml, mess
    } = context;

    try {
      if (!isRegistered) return reply(mess.register);
      if (!MinLimit(m.sender)) return;

      if (!text && !isDocument) {
        return reply('⚠️ Kirim kode sebagai teks atau upload file (.js).');
      }

      await loading();

      if (isDocument) {
        if (!quoted || !quoted.message || !quoted.message.documentMessage) {
          return reply('⚠️ Harap reply file dokumen JavaScript (.js) untuk di-obfuscate.');
        }

        const fileName = quoted.message.documentMessage.fileName || 'file.js';
        if (!fileName.endsWith('.js')) {
          return reply('⚠️ File yang didukung hanya berformat *.js*');
        }

        const mediaPath = await Yudzxml.downloadAndSaveMediaMessage(quoted);
        const outputFile = path.join(__dirname, 'enc_' + path.basename(mediaPath));

        const originalCode = fs.readFileSync(mediaPath, 'utf-8');
        const obfuscated = JavaScriptObfuscator.obfuscate(originalCode, {
          compact: true,
          controlFlowFlattening: true,
          controlFlowFlatteningThreshold: 0.75,
          deadCodeInjection: true,
          deadCodeInjectionThreshold: 0.4,
          stringArray: true,
          stringArrayEncoding: ['base64'],
          selfDefending: true,
          transformObjectKeys: true,
          renameGlobals: false
        });

        fs.writeFileSync(outputFile, obfuscated.getObfuscatedCode());

        await reply(`✅ File berhasil di-obfuscate: *enc_${path.basename(mediaPath)}*`);
        await Yudzxml.sendMessage(m.chat, {
          document: fs.readFileSync(outputFile),
          fileName: `enc_${path.basename(mediaPath)}`,
          mimetype: 'application/javascript',
          caption: '🤖 Berikut hasil obfuscate dari file kamu.'
        }, { quoted: m });

        fs.unlinkSync(mediaPath);
        fs.unlinkSync(outputFile);

      } else {
        const obfuscated = JavaScriptObfuscator.obfuscate(text, {
          compact: true,
          controlFlowFlattening: true,
          controlFlowFlatteningThreshold: 0.75,
          deadCodeInjection: true,
          deadCodeInjectionThreshold: 0.4,
          stringArray: true,
          stringArrayEncoding: ['base64'],
          selfDefending: true,
          transformObjectKeys: true,
          renameGlobals: false
        });

        const hasil = obfuscated.getObfuscatedCode();

        if (hasil.length < 4000) {
          await reply('✅ Berikut hasil obfuscate:\n\n```javascript\n' + hasil + '\n```');
        } else {
          const outputFile = path.join(__dirname, 'enc_text.js');
          fs.writeFileSync(outputFile, hasil);

          await reply('✅ Kode terlalu panjang, dikirim sebagai file: *enc_text.js*');
          await Yudzxml.sendMessage(m.chat, {
            document: fs.readFileSync(outputFile),
            fileName: 'enc_text.js',
            mimetype: 'application/javascript',
            caption: '🤖 Ini hasil obfuscate dari input teks kamu.'
          }, { quoted: m });

          fs.unlinkSync(outputFile);
        }
      }

    } catch (err) {
      console.error('[PLUGIN: obfuscate] ERROR:', err);
      reply('❌ Terjadi kesalahan saat memproses obfuscate.');
    }
  }
};