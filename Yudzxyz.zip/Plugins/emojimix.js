/**
CREATOR: YUDZXML STORE 77
WHATSAPP: 084872031797
CREATE: MIN, 27 JUL 2025
**/

module.exports = {
  command: ['emojimix', 'mixemoji', 'emoji'],
  operate: async (context) => {
    const {
      text, reply, loading, Yudzxml, m,
      isRegistered, isBan, MinLimit, mess, config
    } = context;

    if (!isRegistered) return reply(mess.register);
    if (isBan) return reply(mess.ban);
    if (!MinLimit(m.sender)) return;

    if (!text || !text.includes('+')) {
      return reply('📌 *Contoh penggunaan:* .emojimix 😍+🍕');
    }

    await loading();

    try {
      const [emoji1, emoji2] = text.split('+').map(e => e.trim());

      if (!emoji1 || !emoji2) {
        return reply('❌ Format salah. Gunakan format: emoji1+emoji2');
      }

      const emojiMixer = await import('emoji-mixer');
      const getEmojiMixUrl = emojiMixer.default;
      const { checkSupported } = emojiMixer;

      const isSupported1 = checkSupported(emoji1);
      const isSupported2 = checkSupported(emoji2);

      if (!isSupported1 || !isSupported2) {
        return reply('❌ Salah satu emoji tidak didukung Emoji Kitchen.\nCoba emoji populer seperti 😂🔥💀🍕 dll.');
      }

      const link = getEmojiMixUrl(emoji1, emoji2);

      if (!link) {
        return reply('❌ Kombinasi emoji tidak tersedia.');
      }

      await Yudzxml.sendImageAsSticker(m.chat, link, m, {
        packname: config.packname,
        author: config.author
      });

    } catch (err) {
      console.error('[EMOJIMIX] Terjadi error:', err);
      return reply('⚠️ Terjadi kesalahan saat menggabungkan emoji.');
    }
  }
};