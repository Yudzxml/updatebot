/**
CREATOR: YUDZXML STORE 77
WHATSAPP: 084872031797
CREATE: MIN, 27 JUL 2025
**/

const yts = require('../Storage/scrape/yt-search');
const fetch = require('node-fetch');
const configSetting = require('../settings');
const configMessage = require('../message');

const config = {
  ...configSetting,
  ...configMessage
};

module.exports = {
  command: ['yotubemp3', 'ytmp3', 'youtubemp3'],
  operate: async (context) => {
    const { m, example, reply, isRegistered, isBan, text, Yudzxml, mess, loading, MinLimit, config: contextConfig } = context;

    if (!isRegistered) return reply(mess.register);
    if (isBan) return reply(mess.ban);
    if (!text) return reply(example('https://youtube.xxxx'));

    if (!MinLimit(m.sender)) return;

    await loading();

    try {
      const search = await yts(text);

      if (!search.all || !Array.isArray(search.all) || search.all.length === 0) {
        return reply('Tidak ada video yang ditemukan.');
      }

      const firstVideo = search.all[0];

      const response = await fetch(`https://api-yudzxzy.vercel.app/api/download/ytdl?url=${encodeURIComponent(firstVideo.url)}&format=mp3`);
      const downloadResponse = await response.json();

      if (downloadResponse.error) {
        return reply(`Error: ${downloadResponse.error}`);
      }

      const hasil = downloadResponse.result;

      if (!hasil || !hasil.download) {
        return reply('Gagal mendapatkan link download.');
      }

      await Yudzxml.sendMessage(m.chat, {
        audio: {
          url: hasil.download
        },
        mimetype: 'audio/mpeg',
        contextInfo: {
          externalAdReply: {
            showAdAttribution: false,
            title: firstVideo.title || 'Untitled',
            body: contextConfig.botname || 'Bot',
            sourceUrl: firstVideo.url,
            thumbnailUrl: firstVideo.thumbnail || 'https://example.com/default_thumbnail.jpg',
            mediaType: 1,
            renderLargerThumbnail: true
          }
        }
      }, { quoted: m });

    } catch (error) {
      console.error('Error pada ytmp3 command:', error);
      return reply(mess.error);
    }
  }
};