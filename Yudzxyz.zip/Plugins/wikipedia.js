/**
CREATOR: YUDZXML STORE 77
WHATSAPP: 084872031797
CREATE: MIN, 27 JUL 2025
**/

module.exports = {
  command: ['wikipedia', 'wiki'],
  operate: async (context) => {
    const {
      text, reply, loading, Yudzxml, m,
      isRegistered, isBan, MinLimit, mess, apikey
    } = context;

    if (!isRegistered) {
      await reply(mess.register);
      return;
    }
    if (isBan) {
      await reply(mess.ban);
      return;
    }
    if (!text) {
      await reply('📚 Masukkan kata kunci pencarian Wikipedia, misal: pohon 🌳');
      return;
    }
    if (!MinLimit(m.sender)) return;

    await loading();

    try {
      const res = await fetch(`${apikey.beta}/api/search/wikipedia?text=${encodeURIComponent(text)}&apikey=${apikey.botz}`);
      const json = await res.json();

      if (json.status && json.result) {
        const { title, thumb, isi } = json.result;
        let pesan = `🔍 *${title.toUpperCase()}*\n\n${isi.trim()}\n\n`;
        if (thumb) {
          await Yudzxml.sendMessage(m.chat, { image: { url: thumb }, caption: pesan }, { quoted: m });
        } else {
          await reply(pesan);
        }
      } else {
        await reply('❌ Maaf, data tidak ditemukan.');
      }
    } catch (error) {
      console.error(error);
      await reply('⚠️ Terjadi kesalahan saat mengambil data Wikipedia.');
    }
  }
};