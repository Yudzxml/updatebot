const axios = require('axios');

module.exports = {
    prefix: true,
    command: ['shorten', 'shortlink', 'shorturl', 'shortenlink'],
    operate: async (context) => {
        const { Yudzxml, m, text, prefix, command, loading, example, reply } = context;

        if (!text) {
            await reply(example(`s://example.com*`));
            return;
        }
await loading()
        try {
            const { data: tinyUrlShortUrl } = await axios.get(`https://tinyurl.com/api-create.php?url=${text}`);
            await reply(`Shortened Succes\n\n*TinyURL: ${tinyUrlShortUrl}*`);
        } catch (error) {
            console.error('Error shortening URL:', error);
            await reply('Failed to shorten URL. Please try again later.');
        }
    }
};